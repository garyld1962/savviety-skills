---
name: review-adversarial
description: >-
  Optional adversarial code review using an opposing AI model. Spawns 1–3 reviewers
  on a different model (Codex or Gemini) to challenge work from distinct critical lenses.
  Triggers: "adversarial review", "/review-adversarial".
schedule: "Optional step after /code-review passes, before creating a PR. Use for large changes (200+ lines) or high-risk code (auth, payments, data migrations)."
---

# /review-adversarial — Cross-Model Adversarial Review

Spawn reviewers on a **different AI model** to challenge work. Reviewers attack from distinct
lenses grounded in project conventions. The deliverable is a synthesized verdict — do NOT make
changes.

**This is an optional quality gate.** Use it when the stakes justify the extra scrutiny:
large diffs, security-sensitive code, architectural changes, or data model migrations.

**Hard constraint:** Reviewers MUST run via a different model's CLI. Do NOT use subagents,
the Agent tool, or any internal delegation mechanism — those run on *your own* model, which
defeats the purpose of cross-model review.

## Model Selection

Pick the best available opposite model. Preference order:

| If you are | Preferred opposite | CLI command | Fallback |
|------------|-------------------|-------------|----------|
| Claude | **Codex** (o3/o4-mini) | `codex exec` | `gemini -p` |
| Codex | **Claude** (Opus/Sonnet) | `claude -p` | `gemini -p` |
| Gemini | **Claude** (Opus/Sonnet) | `claude -p` | `codex exec` |

**Why Codex is preferred from Claude:** OpenAI's reasoning models (o3/o4-mini) have genuinely
different training, reasoning patterns, and blind spots. Maximum model diversity = maximum
adversarial value. Gemini is a solid fallback if Codex has issues.

The user can override with `--model=codex` or `--model=gemini`.

## Step 1 — Load Project Context

Read `CLAUDE.md` from repo root. This replaces `brain/principles.md` — your project's
conventions, patterns, and rules ARE the principles that govern reviewer judgments.

Key sections to extract:
- Error handling patterns
- Shared types contract
- Import boundary rules
- Testing expectations
- Things You Must Not Do

## Step 2 — Determine Scope and Intent

Identify what to review from context (recent diffs, referenced plans, user message).

Determine the **intent** — what the author is trying to achieve. Reviewers challenge whether
the work *achieves the intent well*, not whether the intent is correct. State the intent
explicitly before proceeding.

Assess change size:

| Size | Threshold | Reviewers |
|------|-----------|-----------|
| Small | < 50 lines, 1–2 files | 1 (Skeptic) |
| Medium | 50–200 lines, 3–5 files | 2 (Skeptic + Architect) |
| Large | 200+ lines or 5+ files | 3 (Skeptic + Architect + Minimalist) |

Read `references/reviewer-lenses.md` for lens definitions.

## Step 3 — Spawn Reviewers

Create a temp directory for reviewer output:

```sh
REVIEW_DIR=$(mktemp -d /tmp/adversarial-review.XXXXXX)
```

### Using Codex (preferred from Claude):

```sh
codex exec --skip-git-repo-check -o "$REVIEW_DIR/skeptic.md" "prompt" 2>/dev/null
```

Use `--profile edit` only if the reviewer needs to run tests. Default to read-only.
Run with `run_in_background: true`, monitor via `TaskOutput` with `block: true, timeout: 600000`.

### Using Gemini (fallback):

```sh
gemini -p "prompt" > "$REVIEW_DIR/skeptic.md" 2>/dev/null
```

Run with `run_in_background: true`.

Name each output file after the lens: `skeptic.md`, `architect.md`, `minimalist.md`.

### Reviewer prompt template

Each reviewer gets a single prompt containing:

1. The stated intent (from Step 2)
2. Their assigned lens (full text from references/reviewer-lenses.md)
3. The CLAUDE.md conventions relevant to their lens (actual content, not summaries)
4. The code or diff to review
5. Instructions: "You are an adversarial reviewer. Your job is to find real problems, not
   validate the work. Be specific — cite files, lines, and concrete failure scenarios.
   Rate each finding: high (blocks ship), medium (should fix), low (worth noting).
   Write findings as a numbered markdown list to your output file."

Spawn all reviewers in parallel.

## Step 4 — Verify and Synthesize Verdict

Before reading reviewer output, log which CLI was used and confirm the output files exist:

```sh
echo "reviewer_cli=codex|gemini"
ls "$REVIEW_DIR"/*.md
```

If any output file is missing or empty, note the failure in the verdict — do not silently skip
a reviewer.

Read each reviewer's output file from `$REVIEW_DIR/`. Deduplicate overlapping findings.
Produce a single verdict:

```
## Intent
<what the author is trying to achieve>

## Verdict: PASS | CONTESTED | REJECT
<one-line summary>

## Findings
<numbered list, ordered by severity (high → medium → low)>

For each finding:
- **[severity]** Description with file:line references
- Lens: which reviewer raised it
- Convention: which CLAUDE.md rule it maps to (if any)
- Recommendation: concrete action, not vague advice

## What Went Well
<1–3 things the reviewers found no issue with — acknowledge good work>
```

**Verdict logic:**
- **PASS** — no high-severity findings
- **CONTESTED** — high-severity findings but reviewers disagree on them
- **REJECT** — high-severity findings with reviewer consensus

## Step 5 — Render Judgment

After synthesizing the reviewers, apply your own judgment. Using the stated intent and
CLAUDE.md conventions as your frame, state which findings you would accept and which you
would reject — and why. Reviewers are adversarial by design; not every finding warrants
action. Call out false positives, overreach, and findings that mistake style for substance.

Append to the verdict:

```
## Lead Judgment
<for each finding: accept or reject with a one-line rationale>
```

## Workflow Integration

This is an **optional step** in the development workflow. The typical flow:

```
working  → /code-review --quick     (periodic mid-development check)
"done"   → /simplify                (auto-refactor: reuse, quality, efficiency)
clean    → /code-review             (full review — REQUIRED)
passing  → /review-adversarial      (cross-model review — OPTIONAL)
reviewed → create PR
```

**When to use it:**
- Large changes (200+ lines)
- Security-sensitive code (auth, payments, API keys)
- Architectural changes (new packages, schema migrations)
- Before merging to master when confidence matters

**When to skip it:**
- Small bug fixes
- Style/formatting changes
- Documentation updates
- Changes that already have comprehensive test coverage
